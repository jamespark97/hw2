package com.example.hw3;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class WeekActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_week);

        WeekFragment weekFragment = new WeekFragment();
        weekFragment.setSelection(getIntent().getIntExtra("index",-1));
        getSupportFragmentManager().beginTransaction().replace(R.id.weekFrame, weekFragment).commit();
    }
}
