package com.example.hw3;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MonthFragment extends Fragment {
    private GridAdapter gridAdapter;    //그리드뷰 어댑터
    private ArrayList<String> dayList;  //날짜 리스트
    private GridView gridView;          //그리드뷰

    int calYear;                        //년
    int calMonth;                       //월
    int calDay;                         //일
    int firstDay = 0;
    int lastDay = 0;

    public MonthFragment(){
        Date date = new Date();             //Date 객체 생성-오늘 날짜
        calYear = date.getYear();
        calMonth = date.getMonth();
        calDay = date.getDate();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_month, container, false);
        dayList = new ArrayList<String>();
        setCalendar(calYear, calMonth);

        getActivity().setTitle((calYear+1900) + "년 " + (calMonth+1) + "월");

        gridView = view.findViewById(R.id.gridview);
        gridAdapter = new GridAdapter(dayList);
        gridView.setAdapter(gridAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if((0<position-firstDay+1) && (position-firstDay+1)<(firstDay+lastDay)) { //1일~달의 마지막 날이면
                    Activity activity = getActivity();
                    // 선택된 항목 위치(position)을 OnWeekSelectedListener 인터페이스를 구현한 액티비티로 전달
                    if (activity instanceof OnDaySelectedListener)
                        ((MainActivity)activity).onDaySelected(position);
                }
            }
        });

        String[] weeks = {"1주", "2주", "3주", "4주", "5주", "6주"};
        ListView listView = view.findViewById(R.id.listView);
        ArrayAdapter<String> listAdapter = new ArrayAdapter<String>(getActivity() , android.R.layout.simple_list_item_activated_1 ,weeks);
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                // 현재 프래그먼트와 연결된 액티비티를 반환
                Activity activity = getActivity();
                // 선택된 항목 위치(position)을 OnWeekSelectedListener 인터페이스를 구현한 액티비티로 전달
                if (activity instanceof OnWeekSelectedListener)
                    ((MainActivity)activity).onWeekSelected(position);
            }
        });
        return view;
    }

    //그리드 어댑터 클래스
    public class GridAdapter extends BaseAdapter {
        private final List<String> list;            //String 타입 리스트 생성
        private final LayoutInflater inflater;      //layoutInflater 객체 생성

        //생성자
        public GridAdapter(List<String> list) {
            this.list = list;   //매개변수로 입력 받은 날짜 리스트 저장
            this.inflater = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);  //context에서 LayoutInflater가져옴
        }

        @Override
        public int getCount() { return list.size(); }    //크기 반환

        @Override
        public String getItem(int position) { return list.get(position); }  //해당 위치(position)에 있는 항목 반환

        @Override
        public long getItemId(int position) { return position; } //항목 위치 반환

        //View 객체 반환
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;                                                               //ViewHolder 객체 생성후 null 저장


                holder = (ViewHolder)convertView.getTag();                                          //convertView에 저장된 Tag

            holder.tvItemGridView.setText("" + getItem(position));                                  //holder의 TextView의 text를 위치로 변경
            return convertView;                                                                     //  converView 반환
        }
    }

    private class ViewHolder{
        TextView tvItemGridView;
    }

    public void setCalendar(int year, int month){
        Date date = new Date();             //Date 객체 생성
        date.setYear(year);                 //매개변수로 입력받은 년 저장
        date.setMonth(month);               //매개변수로 입력받은 월 저장
        date.setDate(1);                    //일 = 1 저장

        firstDay = date.getDay();       //달의 시작하는 날(월=0, 화=1, 수=2, 목=3, 금=4, 토=5, 일=6)
        lastDay = 0;                    //달의 마지막 날
        int day = 1;                        //날짜

        //달의 마지막 날 구하기
        //1, 3, 5, 7, 8, 10, 12월이면 31일
        //4, 6, 9, 11월이면 30일
        //2월인데 윤년이면 29일, 윤년이 아니면 28일
        switch (calMonth+1){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                lastDay = 31;
                break;
            case 2:
                //윤년인 해
                if((date.getYear()%4 == 0)&&(date.getYear()%100 != 0)||(date.getYear()%400 == 0)){
                    lastDay = 29;
                    break; }
                //윤년이 아닌 해
                else{
                    lastDay = 28;
                    break; }
            case 4: case 6: case 9: case 11:
                lastDay = 30;
                break;
            default:
                break;
        }

        //날짜 리스트에 날짜 채우기
        for(int i=0; i<firstDay; i++){dayList.add("");}                            //달력의 1일 이전 빈칸 추가
        for(int i = firstDay; i<firstDay+lastDay; i++){dayList.add(""+day++);}    //달력의 1일~마지막날 날짜 추가
        for (int i=firstDay+lastDay; i<dayList.size();i++){dayList.add("");}      //달력의 마지막날 이후 빈칸 추가
    }

    public interface OnWeekSelectedListener{
        void onWeekSelected(int i);
    }

    public interface OnDaySelectedListener{
        void onDaySelected(int i);
    }
}
