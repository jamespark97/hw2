package com.example.hw3;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.*;
import android.widget.TextView;
import java.util.*;

public class WeekFragment extends Fragment {
    int index = -1;
    ArrayList<String> dayList;

    Date date = new Date();
    int calYear;
    int calMonth;

    public WeekFragment(){
        calYear = date.getYear();
        calMonth = date.getMonth();

        dayList = new ArrayList<String>(42);
        setCalendar(calYear, calMonth);
    }

    public void setSelection(int i) { index = i; }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_week, container, false);
        TextView WeekDate = (TextView)view.findViewById(R.id.WeekDate);
        TextView Nweek = (TextView)view.findViewById(R.id.Nweek);
        TextView sun = (TextView)view.findViewById(R.id.sunday);
        TextView mon = (TextView)view.findViewById(R.id.monday);
        TextView tue = (TextView)view.findViewById(R.id.tuesday);
        TextView wed = (TextView)view.findViewById(R.id.wednesday);
        TextView thu = (TextView)view.findViewById(R.id.thursday);
        TextView fri = (TextView)view.findViewById(R.id.friday);
        TextView sat = (TextView)view.findViewById(R.id.saturday);

        WeekDate.setText((date.getYear()+1900) + "년/" + (date.getMonth()+1) + "월");
        if (index >=0){
            Nweek.setText((index+1)+"주");

            sun.setText(""+dayList.get(7*index));
            mon.setText(""+dayList.get(7*index+1));
            tue.setText(""+dayList.get(7*index+2));
            wed.setText(""+dayList.get(7*index+3));
            thu.setText(""+dayList.get(7*index+4));
            fri.setText(""+dayList.get(7*index+5));
            sat.setText(""+dayList.get(7*index+6));
        }
        return view;
    }

    public void setCalendar(int year, int month){
        Date date = new Date();             //Date 객체 생성
        date.setYear(year);                 //매개변수로 입력받은 년 저장
        date.setMonth(month);               //매개변수로 입력받은 월 저장
        date.setDate(1);                    //일 = 1 저장

        int firstDay = date.getDay();       //달의 시작하는 날(월=0, 화=1, 수=2, 목=3, 금=4, 토=5, 일=6)
        int lastDay = 0;                    //달의 마지막 날
        int day = 1;                        //날짜

        //달의 마지막 날 구하기
        //1, 3, 5, 7, 8, 10, 12월이면 31일
        //4, 6, 9, 11월이면 30일
        //2월인데 윤년이면 29일, 윤년이 아니면 28일
        switch (date.getMonth()+1){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                lastDay = 31;
                break;
            case 2:
                //윤년인 해
                if((date.getYear()%4 == 0)&&(date.getYear()%100 != 0)||(date.getYear()%400 == 0)){
                    lastDay = 29; break; }
                //윤년이 아닌 해
                else{
                    lastDay = 28; break; }
            case 4: case 6: case 9: case 11:
                lastDay = 30; break;
            default:
                break;
        }

        //날짜 리스트에 날짜 채우기
        for(int i=0; i<firstDay; i++){dayList.add("");}                           //달력의 1일 이전 빈칸 추가
        for(int i = firstDay; i<firstDay+lastDay; i++){dayList.add(""+day++);}    //달력의 1일~마지막날 날짜 추가
        for(int i=firstDay+lastDay; i<42;i++){dayList.add("");}       //달력의 마지막날 이후 빈칸 추가
    }
}
